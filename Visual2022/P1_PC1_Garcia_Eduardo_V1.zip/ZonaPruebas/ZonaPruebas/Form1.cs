﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZonaPruebas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            float mRadiusE = 5.0f; // Radio externo
            float mRadiusI = 9.0f; // Radio interno
            float centerX = picCanvas.Width / 2;
            float centerY = picCanvas.Height / 2;
            float SF = 10;

            Pen bluePen = new Pen(Color.Blue, 3);     // Estrella original
            Pen redPen = new Pen(Color.Red, 2);       // Estrella rotada
            Pen linePen = new Pen(Color.Green, 1);    // Líneas al centro

            // Función para generar puntos de estrella
            PointF[] GenerateStarPoints(double startAngle)
            {
                PointF[] points = new PointF[10];
                double angle = startAngle;

                for (int i = 0; i < 10; i++)
                {
                    float radius = (i % 2 == 0) ? mRadiusE * SF : mRadiusI * SF;
                    float x = centerX + (float)(radius * Math.Cos(angle));
                    float y = centerY + (float)(radius * Math.Sin(angle));
                    points[i] = new PointF(x, y);
                    angle += Math.PI / 5;
                }

                return points;
            }

            // Estrella original
            PointF[] starOriginal = GenerateStarPoints(Math.PI / 2);
            e.Graphics.DrawPolygon(bluePen, starOriginal);

            // Estrella rotada
            PointF[] starRotated = GenerateStarPoints(60);
            e.Graphics.DrawPolygon(redPen, starRotated);

            // Dibujar líneas desde el centro hasta las puntas interiores de la estrella original
            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0) // Solo las puntas interiores
                {
                    e.Graphics.DrawLine(linePen, centerX, centerY, starOriginal[i].X, starOriginal[i].Y);
                    e.Graphics.DrawLine(linePen, centerX, centerY, starRotated[i].X, starRotated[i].Y);
                }
            }






        }



    }
}
